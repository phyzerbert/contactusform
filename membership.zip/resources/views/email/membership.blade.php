<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Membership Agreement</title>
</head>
<body>
    <div>
        <p>
            I just tested the Membership form when I fill it in and submit
            using my email as the customer.
            It shows me the name are you and the subject as the RISK WARNING AND WAIVER FIRST TIME INFO.
            The email address should be either info@gbsurfersparadise.com.au or forms@learnjiujitsu.com.au
            I and the subject should be Membership for the membership form.
        </p>
    </div>
</body>
</html>